package com.jerson.soundeyes.feature_app.presentation.main

data class MainState(
    val permission: Boolean
)