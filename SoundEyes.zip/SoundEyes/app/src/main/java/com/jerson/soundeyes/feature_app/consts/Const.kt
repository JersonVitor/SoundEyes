package com.jerson.soundeyes.feature_app.consts

object Const {
    const val LABELS_YOLO = "labelsYolo.txt"
    const val LABELS_MOBNET = "labelsMobileNet.txt"
}